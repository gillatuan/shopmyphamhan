Hey <?php echo $username;?>,<br/>
<br/>
Your account has been created <br/>
<br/>
If you have any questions, contact with us.<br/>
<br/>
Thanks,<br/>
The Web3in1.com Team<br/>
<br/>