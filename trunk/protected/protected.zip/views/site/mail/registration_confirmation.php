Hello, <?php echo $username;?>,<br/>
<br/>
Thank you for registering your account! 
In order to complete your registration, please confirm your email following the link below 
(you may also paste into your browser):<br/>
<br/>
<?php echo $link;?><br/>
<br/>
<br />
<strong>Your login detail:</strong><br />
Username: <?php echo $username; ?><br />
Password: <?php echo $password; ?><br />
<br />
PLEASE DO NO REPLY TO THIS EMAIL. THIS IS AN AUTO-GENERATED EMAIL MESSAGE.<br/>
<br/>
Thank you,<br/>
<br/>
The Flexicore Team<br/>
<br/>