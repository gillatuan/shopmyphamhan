<?php echo $name;?> have just send contact to you. Detail: <br/>
<br/>
<strong>Title: </strong><?php echo $title; ?>
<br />
<strong>Comment: </strong><?php echo $comment; ?><br />
<br />