Hi <?php echo $username;?>,<br/>
<br/>
You recently asked to reset your Flexicore password. To complete your request, please follow this link:<br/>
<br/>
<?php echo $link;?><br/>
<br/>
<br/>
Please note: for your protection, a copy of this email has been sent to all the email addresses associated with your Flexicore account.<br/>
<br/>
If you did not request a new password, you may disregard this message.<br/>
<br/>
Thanks,<br/>
The Flexicore Team<br/>
<br/>