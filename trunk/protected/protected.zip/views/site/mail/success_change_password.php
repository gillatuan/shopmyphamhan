Hey <?php echo $username; ?>,<br/>
<br/>
You recently changed your password at Web3in1.com site. As a security precaution, this notification has been sent to all email addresses associated with your account.
<br/>
<br/>
If you did not request a new password, you may disregard this message.<br/>
<br/>
Thanks,<br/>
The Web3in1 Team